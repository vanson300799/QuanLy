﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using WEB.Filters;
using WebMatrix.WebData;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using WebModels;
using Newtonsoft.Json.Linq;
using System.Data;
using System;
using System.Collections.Generic;
using Common;
using WEB.Models;
using Kendo.Mvc;
using WEB.Areas.Admin.Controllers;

namespace WEB.Areas.ContentType.Controllers
{
    [AdminAuthorize]
    public class FAQController : BaseController
    {
        WebContext db = new WebContext();
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
        [NonAction]
        protected void UpdateLocales(WebFAQ model)
        {

            foreach (var localized in model.Locales)
            {
                using (var _localizedEntityService = new LocalizedEntityService())
                {
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Title, localized.Title, localized.LanguageID);
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Ans, localized.Ans, localized.LanguageID);
                }

            }
        }

        [ChildActionOnly]
        public ActionResult _Index(int id)
        {
            ViewBag.ID = id;
            return PartialView();
        }

        [ChildActionOnly][AllowAnonymous]
        public ActionResult _IndexPublish(int id)
        {
            var contents = db.WebFAQs.Where(x => x.WebModuleID == id).OrderByDescending(x => x.ID).ToList(); 


            return PartialView(contents);
        }

        public ActionResult WebContent_Read([DataSourceRequest] DataSourceRequest request, int id)
        {
            var contents = db.WebFAQs.Where(x => x.WebModuleID == id).Select(x => new { x.ID, x.Title, x.ModifiedBy, x.ModifiedDate });
            if (request.Sorts.Count == 0)
            {
                request.Sorts.Add(new SortDescriptor("ID", System.ComponentModel.ListSortDirection.Descending));
            }
            return Json(contents.ToDataSourceResult(request));
        }

        public JsonResult GetWebContents(string text, int id)
        {
            {
                var contents = from x in db.WebFAQs where x.WebModuleID == id select x;
                if (!string.IsNullOrEmpty(text))
                {
                    contents = contents.Where(p => p.Title.Contains(text));
                }

                return Json(contents, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult Add(int id)
        {
            ViewBag.ID = id;
            var model = new WebFAQ();
            AddLocales(model.Locales, null);
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Add([Bind(Exclude = "Object")]WebFAQ model)
        {
            if (ModelState.IsValid)
            {
                model.CreatedBy = WebSecurity.CurrentUserName;
                model.CreatedDate = DateTime.Now;
                model.ModifiedBy = WebSecurity.CurrentUserName;
                model.ModifiedDate = DateTime.Now;

                db.Set<WebFAQ>().Add(model);
                db.SaveChanges(); UpdateLocales(model);
                ViewBag.StartupScript = "create_success();";
                return View(model);
            }
            else
            {
                return View(model);
            }
        }
        public ActionResult Edit(int id)
        {
             
                var model = db.Set<WebFAQ>().Find(id);
                if (model == null)
                {
                    return HttpNotFound();
                }
                AddLocales(model.Locales, (locale, languageId) =>
                {
                    locale.Title = model.GetLocalized(x => x.Title, languageId, false, false);
                    locale.Ans = model.GetLocalized(x => x.Ans, languageId, false, false);
                });
                return View("Edit", model);
            
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Edit([Bind(Exclude = "Object")]WebFAQ model)
        {
            if (ModelState.IsValid)
            {

                {
                    try
                    {
                        model.ModifiedBy = WebSecurity.CurrentUserName;
                        model.ModifiedDate = DateTime.Now;

                        db.WebFAQs.Attach(model);
                        db.Entry(model).Property(a => a.Title).IsModified = true;
                        db.Entry(model).Property(a => a.Ans).IsModified = true;
                        db.Entry(model).Property(a => a.ModifiedBy).IsModified = true;
                        db.Entry(model).Property(a => a.ModifiedDate).IsModified = true;
                        db.SaveChanges(); UpdateLocales(model);
                        ViewBag.StartupScript = "edit_success();";
                        return View(model);

                    }
                    catch (Exception ex)
                    {

                        ModelState.AddModelError("", ex.Message);
                        return View(model);
                    }
                }
            }
            else
            {
                return View(model);
            }
        }
        public ActionResult Delete(int id)
        {
            {
                var model = db.Set<WebFAQ>().Find(id);
                if (model == null)
                {
                    return HttpNotFound();
                }
                using (var _localizedEntityService = new LocalizedEntityService())
                {
                    _localizedEntityService.DeleteLocalizedValue(model);
                }  
                ViewBag.Ans = model.Ans;
                return View("Delete", model);
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Delete(WebFAQ model)
        {
            {

                try
                {
                    db.Entry(model).State = EntityState.Deleted;
                    db.SaveChanges();
                    ViewBag.StartupScript = "delete_success();";
                    return View();
                }
                catch (Exception ex)
                {

                    ModelState.AddModelError("", ex.Message);
                    return View(model);
                }
            }
        }

        public ActionResult Deletes(string id)
        {

            var objects = id.Split(',');
            var lstObjId = new List<int>();
            foreach (var obj in objects)
            {
                try
                {
                    lstObjId.Add(int.Parse(obj.ToString()));
                }
                catch (Exception)
                { }
            }

            {
                var temp = from p in db.Set<WebFAQ>()
                           where lstObjId.Contains(p.ID)
                           select p;

                return View(temp.ToList());
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Deletes(List<WebFAQ> model)
        {

            {
                var temp = new List<WebFAQ>();
                foreach (var item in model)
                {
                    try
                    {
                        db.Entry(item).State = EntityState.Deleted;
                        db.SaveChanges();
                        using (var _localizedEntityService = new LocalizedEntityService())
                        {
                            _localizedEntityService.DeleteLocalizedValue(item);
                        }  
                    }
                    catch (Exception)
                    {
                        db.Entry(item).State = EntityState.Unchanged;
                        temp.Add(item);
                    }
                }

                if (temp.Count == 0)
                {
                    ViewBag.StartupScript = "deletes_success();";
                    return View(temp);
                }
                else if (temp.Count > 0)
                {
                    ViewBag.StartupScript = "top.$('#grid').data('kendoGrid').dataSource.read();";
                    ModelState.AddModelError("", Resources.Common.ErrorDeleteItems);
                    return View(temp);
                }
                else
                {
                    ViewBag.StartupScript = "deletes_success();";
                    return View();
                }
            }
        }

        [HttpPost]
        public ContentResult CkImageUpload(int id)
        {
            var url = ""; var CKEditorFuncNum = "";

            HttpPostedFileBase uploads = Request.Files["upload"];
            CKEditorFuncNum = Request["CKEditorFuncNum"];
            if (uploads != null)
            {
                try
                {
                    var name = uploads.FileName;
                    var newName = Utility.GeneratorFileName(name);
                    var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath("/content/uploads/faq/auto/"));
                    if (!dir.Exists) dir.Create();
                    var fullpath = "/content/uploads/faq/auto/" + newName;
                    uploads.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));
                    url = fullpath;

                    try
                    {
                        if (ImageTools.ValidateImage(System.Web.HttpContext.Current.Server.MapPath(fullpath)))
                        {
                            var result = ImageTools.ResizeImage(System.Web.HttpContext.Current.Server.MapPath(fullpath), System.Web.HttpContext.Current.Server.MapPath(fullpath), 1000, 3000, true, 80);
                        }
                        else
                        {
                            Utility.DeleteFile(fullpath);
                        }
                    }
                    catch (Exception)
                    { }
                }
                catch (Exception)
                { }
            }
            return Content("<script>window.parent.CKEDITOR.tools.callFunction(" + CKEditorFuncNum + ", \"" + url + "\");</script>");
        }

    }
}
