﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEB.Areas.ContentType.Controllers
{
    public class ProductController : Controller
    {
        [ChildActionOnly]
        public ActionResult _Index(int id)
        {
            return PartialView();
        }

    }
}
