﻿using Common;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebMatrix.WebData;
using WebModels;

namespace WEB.Areas.ContentType.Controllers
{
    public class PhotoController : Controller
    {
        WebContext db = new WebContext();
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
        [ChildActionOnly]
        public ActionResult _Index(int id)
        {
            ViewBag.ID = id;
            return PartialView();
        }
    
      
        public ActionResult Photos_Read([DataSourceRequest] DataSourceRequest request, int id)
        {
            
            var contents = db.WebContents.Where(x => x.WebModuleID == id).OrderByDescending(x => x.ID).Select(x => new { x.ID, x.Title, x.Image, x.ModifiedBy, x.ModifiedDate}).ToList();
            var t = from x in contents select new { x.ID, x.Title, x.Image, x.ModifiedBy, x.ModifiedDate, Thumb = Utility.GetThumbImagePath(x.Image) }; 
            return Json(t.ToDataSourceResult(request));
        }
        public ActionResult Add(int id)
        {
            ViewBag.ID = id;
            return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public JsonResult uploadImage(int id, FormCollection form)
        {

            foreach (string files in Request.Files)
            {
                HttpPostedFileBase file = Request.Files[files];
                if (file != null)
                {
                    var title = form["title"];
                    var fileName = Path.GetFileName(file.FileName);
                    var newName = Utility.GeneratorFileName(fileName);
                    Utility.CreateFloder("~/Content/Uploads/Photo/" + id); Utility.CreateFloder("~/Content/Uploads/Photo/" + id + "/_thumbs/");
                    var physicalPath = Path.Combine(Server.MapPath("~/Content/Uploads/Photo/" + id + "/"), newName);
                    var thumbphysicalPath = Server.MapPath("~/Content/Uploads/Photo/" + id + "/_thumbs/") + newName;
                    file.SaveAs(physicalPath);
                    if (ImageTools.ValidateImage(physicalPath))
                    {
                        if (System.IO.File.Exists(thumbphysicalPath))
                        {
                            System.IO.File.Delete(thumbphysicalPath);
                        }
                        var result = ImageTools.ResizeImage(physicalPath, thumbphysicalPath, 240, 240, true, 80); 
                        
                        var model = new WebContent();
                        model.Title = !string.IsNullOrEmpty(title) ? title : fileName;
                        model.Image = "/Content/Uploads/Photo/" + id + "/" + newName;
                        model.WebModuleID = id;
                        model.CreatedBy = WebSecurity.CurrentUserName;
                        model.CreatedDate = DateTime.Now;
                        model.ModifiedBy = WebSecurity.CurrentUserName;
                        model.ModifiedDate = DateTime.Now;
                        model.MetaTitle = Utility.ToUnsignString(model.Title);
                        db.Set<WebContent>().Add(model);
                        db.SaveChanges();
                        return Json(new { success = true, data = String.Format(Resources.Common.UploadSuccessFile, "Tải thành công tệp " + (string.IsNullOrEmpty(title) ? title : fileName)) });
                    }
                    else
                    {
                        try
                        {
                            if (System.IO.File.Exists(physicalPath))
                            {
                                System.IO.File.Delete(physicalPath);
                            }
                            return Json(new { success = false, data = "Tệp " + (string.IsNullOrEmpty(title) ? title : fileName)+ " không hợp lệ" }); 
                        }
                        catch (Exception)
                        {
                            return Json(new { success = false, data = "Lỗi khi tải file " + (string.IsNullOrEmpty(title) ? title : fileName) }); 
                        }
                    }

                }
            }

            return Json(new { success = false, data = "Chưa chọn tệp tải lên" }); 
        }


        public ActionResult Edit(int id)
        {
             
            {
                var model = db.Set<WebContent>().Find(id);
                if (model == null)
                {
                    return HttpNotFound();
                }
                return View("Edit", model);
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Edit([Bind(Exclude = "Object")]WebContent model, HttpPostedFileBase image)
        {
            if (ModelState.IsValid)
            {
                
                {
                    try
                    {
                        var currentimg = model.Image;
                        model.ModifiedBy = WebSecurity.CurrentUserName;
                        model.ModifiedDate = DateTime.Now; 
                        if (image != null)
                        {
                              
                            image.SaveAs(System.Web.HttpContext.Current.Server.MapPath(currentimg));
                            var physicalPath = Server.MapPath(currentimg);
                            var thumbphysicalPath = Server.MapPath(Utility.GetThumbImagePath(currentimg));
                            if (System.IO.File.Exists(thumbphysicalPath))
                            {
                                System.IO.File.Delete(thumbphysicalPath);
                            }
                            var result = ImageTools.ResizeImage(physicalPath, thumbphysicalPath, 240, 240, true, 80);  
                            
                        }
                        model.MetaTitle = Utility.ToUnsignString(model.Title);
                        db.WebContents.Attach(model);
                        db.Entry(model).Property(a => a.Title).IsModified = true; db.Entry(model).Property(a => a.MetaTitle).IsModified = true;
                        db.Entry(model).Property(a => a.Image).IsModified = model.Image != null; 
                        db.Entry(model).Property(a => a.ModifiedBy).IsModified = true;
                        db.Entry(model).Property(a => a.ModifiedDate).IsModified = true;
                        db.SaveChanges();
                        ViewBag.StartupScript = "edit_success();";
                        return View(model);

                    }
                    catch (Exception ex)
                    {

                        ModelState.AddModelError("", ex.Message);
                        return View(model);
                    }
                }
            }
            else
            {
                return View(model);
            }
        }
        public ActionResult Delete(int id)
        {
             
            {
                var model = db.Set<WebContent>().Find(id);
                if (model == null)
                {
                    return HttpNotFound();
                }
                return View("Delete", model);
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(WebContent model)
        {

             
            {

                try
                {
                    Utility.DeleteFile(model.Image);
                    Utility.DeleteFile(Utility.GetThumbImagePath(model.Image));
                    db.Entry(model).State = EntityState.Deleted;
                    db.SaveChanges();
                    ViewBag.StartupScript = "delete_success();";
                    return View(model);
                }
                catch (Exception ex)
                {

                    ModelState.AddModelError("", ex.Message);
                    return View(model);
                }
            }
        }
        public ActionResult _IndexPublish(int id, int? page)
        {
            var contents = db.WebContents.Where(x => x.WebModuleID == id).OrderByDescending(x => x.CreatedDate).ToList();

            #region Xử lý phân trang
            int ilimit = 8; //Số bản ghi hiển thị trên một trang
            int ipage = 1;
            if (page != null) ipage = page.Value;
            int count = contents.Count();
            if (ilimit > 0 && ipage > 0)
            {
                int start = (ipage - 1) * ilimit;
                contents = contents.Skip(start).Take(ilimit).ToList();
            }
            var totalPage = 0;
            try
            {
                totalPage = (int)Math.Ceiling((double)count / ilimit);
            }
            catch (Exception)
            { }
            ViewBag.ID = id;
            ViewBag.Page = ipage;
            ViewBag.Total = count; ViewBag.TotalPage = totalPage;
            ViewBag.Next = ipage + 1; if (ipage == totalPage) ViewBag.Next = 1;
            ViewBag.Prev = ipage - 1; if (ipage == 1) ViewBag.Prev = totalPage;
            #endregion
            return PartialView(contents);
        }

    }
}
