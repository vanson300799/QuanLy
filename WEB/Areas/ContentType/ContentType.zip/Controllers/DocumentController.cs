﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using WEB.Filters;
using WebMatrix.WebData;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using WebModels;
using Newtonsoft.Json.Linq;
using System.Data;
using System;
using System.Collections.Generic;
using Common;
using Kendo.Mvc;
using WEB.Areas.Admin.Controllers;
using WEB.Models;

namespace WEB.Areas.ContentType.Controllers
{
    public class DocumentController : BaseController
    {
        private WebContext db = new WebContext(); 
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
        [NonAction]
        protected void UpdateLocales(WebContent model)
        {

            foreach (var localized in model.Locales)
            {
                using (var _localizedEntityService = new LocalizedEntityService())
                {
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Title, localized.Title, localized.LanguageID);
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Description, localized.Description, localized.LanguageID);
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Image, localized.Image, localized.LanguageID);
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Link , localized.Link, localized.LanguageID);
                    _localizedEntityService.SaveLocalizedValue(model, x => x.Body, localized.Body, localized.LanguageID);
                }

            }
        }

        [ChildActionOnly]
        public ActionResult _Index(int id)
        {
            ViewBag.ID = id; 
            return PartialView();
        }

        [ChildActionOnly]
        public ActionResult _IndexPublish(int id)
        {
            IEnumerable<WebContent> documents = (from c in this.db.WebContents where c.WebModuleID == id && c.Status == (int)Status.Public select c).ToList();

            return PartialView(documents);
        }

        public ActionResult WebDocument_FilterTitle(int id)
        {
            return Json(this.db.WebContents.Where(m => m.WebModuleID == id).Select(m => m.Title).Distinct(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult WebDocument_Read([DataSourceRequest] DataSourceRequest request, int id)
        {
            var contents = db.WebContents.Where(x => x.WebModuleID == id).Select(x => new { x.ID, x.Title, x.ModifiedBy, x.ModifiedDate,x.Link,x.Image }); 
            if (request.Sorts.Count == 0)
            {
                request.Sorts.Add(new SortDescriptor("ID", System.ComponentModel.ListSortDirection.Descending));
            } 
            return Json(contents.ToDataSourceResult(request));
        }

        public ActionResult Add(int id)
        {
            ViewBag.ID = id;
            var model = new WebContent();
            AddLocales(model.Locales, null);
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Add([Bind(Exclude = "Object")]WebContent model, HttpPostedFileBase image, HttpPostedFileBase attachFile)
        {
            if (ModelState.IsValid)
            {
                model.CreatedBy = WebSecurity.CurrentUserName;
                model.CreatedDate = DateTime.Now;
                model.ModifiedBy = WebSecurity.CurrentUserName;
                model.ModifiedDate = DateTime.Now;

                if (image != null)
                {
                    var name = image.FileName;
                    var newName = Utility.GeneratorFileName(name);
                    string path = "/content/uploads/document/image/";
                    var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath(path));
                    if (!dir.Exists) dir.Create();
                    var fullpath = path + newName;
                    image.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));

                    try
                    {
                        if (ImageTools.ValidateImage(System.Web.HttpContext.Current.Server.MapPath(fullpath)))
                        {
                            var result = ImageTools.ResizeImage(System.Web.HttpContext.Current.Server.MapPath(fullpath), System.Web.HttpContext.Current.Server.MapPath(fullpath), 500, 500, true, 80);
                        }
                        else
                        {
                            Utility.DeleteFile(fullpath);
                        }
                    }
                    catch (Exception)
                    { }

                    model.Image = fullpath;
                }

                if (attachFile != null)
                {
                    var name = attachFile.FileName;
                    var newName = Utility.GeneratorFileName(name);
                    string path = "/content/uploads/document/";
                    var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath(path));
                    if (!dir.Exists)
                        dir.Create();
                    var fullpath = path + newName;
                    model.Link = fullpath;

                    attachFile.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));
                }

               foreach(var local in model.Locales)
               {
                   var localimage = Request.Files.Get("image-" + local.LanguageID);
                   var locallink= Request.Files.Get("link-" + local.LanguageID);
                   if (localimage != null)
                   {
                       var name = localimage.FileName;
                       var newName = Utility.GeneratorFileName(name);
                       string path = "/content/uploads/document/image/";
                       var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath(path));
                       if (!dir.Exists) dir.Create();
                       var fullpath = path + newName;
                       localimage.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));

                       try
                       {
                           if (ImageTools.ValidateImage(System.Web.HttpContext.Current.Server.MapPath(fullpath)))
                           {
                               var result = ImageTools.ResizeImage(System.Web.HttpContext.Current.Server.MapPath(fullpath),
                                   System.Web.HttpContext.Current.Server.MapPath(fullpath), 500, 500, true, 80);
                           }
                           else
                           {
                               Utility.DeleteFile(fullpath);
                           }
                       }
                       catch (Exception)
                       { }
                       model.Locales.Where(x => x.LanguageID == local.LanguageID).First().Image = fullpath; 
                   }

                   if (locallink != null)
                   {
                       var name = locallink.FileName;
                       var newName = Utility.GeneratorFileName(name);
                       string path = "/content/uploads/document/";
                       var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath(path));
                       if (!dir.Exists)  dir.Create();
                       var fullpath = path + newName;

                       locallink.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));
                       model.Locales.Where(x => x.LanguageID == local.LanguageID).First().Link  = fullpath;
                   }
               }

                db.Set<WebContent>().Add(model);
                db.SaveChanges();
                UpdateLocales(model);

                ViewBag.StartupScript = "create_success();";

                return View(model);
            }
            else
            {
                return View(model);
            }
        }

        public ActionResult Edit(int id)
        {
            var model = db.Set<WebContent>().Find(id);

            if (model == null)
            {
                return HttpNotFound();
            }
            AddLocales(model.Locales, (locale, languageId) =>
            {
                locale.Title = model.GetLocalized(x => x.Title, languageId, false, false);
                locale.Description = model.GetLocalized(x => x.Description, languageId, false, false);
                locale.Body = model.GetLocalized(x => x.Body, languageId, false, false);
                locale.Link = model.GetLocalized(x => x.Link, languageId, false, false);
                locale.Image = model.GetLocalized(x => x.Image, languageId, false, false);
            });
            return View("Edit", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Edit([Bind(Exclude = "Object")]WebContent model, HttpPostedFileBase image, HttpPostedFileBase attachFile)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    model.ModifiedBy = WebSecurity.CurrentUserName;
                    model.ModifiedDate = DateTime.Now;

                    if (image != null)
                    {
                        var name = image.FileName;
                        var newName = Utility.GeneratorFileName(name);
                        string path = "/content/uploads/document/image/";
                        var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath(path));
                        if (!dir.Exists) dir.Create();
                        var fullpath = path + newName;
                        image.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));

                        try
                        {
                            if (ImageTools.ValidateImage(System.Web.HttpContext.Current.Server.MapPath(fullpath)))
                            {
                                var result = ImageTools.ResizeImage(System.Web.HttpContext.Current.Server.MapPath(fullpath), System.Web.HttpContext.Current.Server.MapPath(fullpath), 500, 500, true, 80);
                            }
                            else
                            {
                                Utility.DeleteFile(fullpath);
                            }
                        }
                        catch (Exception)
                        { }

                        model.Image = fullpath;
                    }

                    if (attachFile != null)
                    {
                        var name = attachFile.FileName;
                        var newName = Utility.GeneratorFileName(name);
                        string path = "/content/uploads/document/";
                        var dir = new System.IO.DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath(path));
                        if (!dir.Exists)
                            dir.Create();
                        var fullpath = path + newName;
                        model.Link = fullpath;

                        attachFile.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));
                    }

                    db.WebContents.Attach(model);
                    db.Entry(model).Property(a => a.Title).IsModified = true;
                    db.Entry(model).Property(a => a.Description).IsModified = true; 
                    db.Entry(model).Property(a => a.Status).IsModified = true;
                    db.Entry(model).Property(a => a.Image).IsModified = true;
                    db.Entry(model).Property(a => a.Link).IsModified = true;
                    db.Entry(model).Property(a => a.Body).IsModified = true;
                    db.Entry(model).Property(a => a.ModifiedBy).IsModified = true;
                    db.Entry(model).Property(a => a.ModifiedDate).IsModified = true;
                    db.SaveChanges();



                    foreach (var local in model.Locales)
                    {
                        var localimage = Request.Files.Get("image-" + local.LanguageID);
                        var locallink = Request.Files.Get("link-" + local.LanguageID);
                        if (localimage != null && localimage.ContentLength>0)
                        {
                            var name = localimage.FileName;
                            var newName = Utility.GeneratorFileName(name);
                            string path = "/content/uploads/document/image/"; 
                            var fullpath = path + newName;
                            localimage.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));

                            try
                            {
                                if (ImageTools.ValidateImage(System.Web.HttpContext.Current.Server.MapPath(fullpath)))
                                {
                                    var result = ImageTools.ResizeImage(System.Web.HttpContext.Current.Server.MapPath(fullpath),
                                        System.Web.HttpContext.Current.Server.MapPath(fullpath), 500, 500, true, 80);
                                }
                                else
                                {
                                    Utility.DeleteFile(fullpath);
                                }
                            }
                            catch (Exception)
                            { }
                            model.Locales.Where(x => x.LanguageID == local.LanguageID).First().Image = fullpath;
                        }

                        if (locallink != null && locallink.ContentLength > 0)
                        {
                            var name = locallink.FileName;
                            var newName = Utility.GeneratorFileName(name);
                            string path = "/content/uploads/document/"; 
                            var fullpath = path + newName;

                            locallink.SaveAs(System.Web.HttpContext.Current.Server.MapPath(fullpath));
                            model.Locales.Where(x => x.LanguageID == local.LanguageID).First().Link = fullpath;
                        }
                    }

                    UpdateLocales(model);
                    ViewBag.StartupScript = "edit_success();";
                    return View(model);
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                    return View(model);
                }
            }
            else
            {
                return View(model);
            }
        }

        public ActionResult Delete(int id)
        {
            var model = db.Set<WebContent>().Find(id);

            if (model == null)
            {
                return HttpNotFound();
            }

            return View("Delete", model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(WebContent model)
        {
            try
            {
                db.Entry(model).State = EntityState.Deleted;
                db.SaveChanges(); 
                using (var _localizedEntityService = new LocalizedEntityService())
                {
                    _localizedEntityService.DeleteLocalizedValue(model);
                } 
                ViewBag.StartupScript = "delete_success();";
                return View();
            }
            catch (Exception ex)
            {

                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        public ActionResult Deletes(string id)
        {
            var objects = id.Split(',');
            var lstObjId = new List<int>();

            foreach (var obj in objects)
            {
                try
                {
                    lstObjId.Add(int.Parse(obj.ToString()));
                }
                catch (Exception)
                { }
            }

            var temp = from p in db.Set<WebContent>()
                       where lstObjId.Contains(p.ID)
                       select p;

            return View(temp.ToList());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Deletes(List<WebContent> model)
        {
            var temp = new List<WebContent>();

            foreach (var item in model)
            {
                try
                {
                    db.Entry(item).State = EntityState.Deleted;
                    db.SaveChanges();
                    using (var _localizedEntityService = new LocalizedEntityService())
                    {
                        _localizedEntityService.DeleteLocalizedValue(item);
                    } 
                }
                catch (Exception)
                {
                    db.Entry(item).State = EntityState.Unchanged;
                    temp.Add(item);
                }
            }

            if (temp.Count == 0)
            {
                ViewBag.StartupScript = "deletes_success();";

                return View(temp);
            }
            else if (temp.Count > 0)
            {
                ViewBag.StartupScript = "top.$('#grid').data('kendoGrid').dataSource.read();";
                ModelState.AddModelError("", Resources.Common.ErrorDeleteItems);

                return View(temp);
            }
            else
            {
                ViewBag.StartupScript = "deletes_success();";

                return View();
            }
        }
    }
}
